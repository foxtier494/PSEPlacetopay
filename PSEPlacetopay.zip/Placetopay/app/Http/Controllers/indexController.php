<?php

namespace App\Http\Controllers;

use App\documents;
use App\placetopays;
use App\statuses;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use PlaceToPay\SDKPSE\Helpers\Validate;
use PlaceToPay\SDKPSE\SDKPSE;
use Validator;

class indexController extends Controller
{
    private function config()
    {
        return array(
            "login" => '6dd490faf9cb87a9862245da41170ff2',
            "tran_key" => '024h1IlD',
            "cache" => array(
                "type" => "memcached",
                "memcached" => array(
                    "host" => "127.0.0.1",
                    "port" => "11211"
                )
            )
        );
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $mov = new SDKPSE($this->config());

        $listDocumentos = documents::all();
        $banks = $mov->getBankList($mov);

        return view('pagos.index',compact('banks','listDocumentos'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(),[
             'documentType' => 'required',
              'document' => 'required',
              'bankInterface' => 'required',
              'bankCode' => 'required',
              'firstName' => 'required',
              'lastName' => 'required',
              'country' => 'required',
              'province' => 'required',
              'city' => 'required',
              'phone' => 'required',
              'description' => 'required',
              'emailAddress' => 'required',
              'address' => 'required',
              'monto' => 'required'
        ]);

        if($validator->fails())
        {
            flash('<i class="fa fa-warning"></i> Todos los campos son requerido.')->warning();
            return Redirect::route('create');
        }


        $mov = new SDKPSE($this->config());

        $date = date('ymdHis');

        $pseBase = (object) [
                'bankCode' => $request->bankCode,
                'bankInterface' => $request->bankInterface,
                'returnURL' => route('show',base64_encode($date.$request->document)),
                'reference' => $date,
                'description' => $request->description.' '.$date,
                'language' => 'ES',
                'currency' => 'COP',
                'ipAddress' =>  $request->ip(),
                'userAgent' =>  $request->header('User-Agent'),
                'totalAmount' => $request->monto,
                'taxAmount' => 0,
                'devolutionBase' => 0,
                'tipAmount' => 0,
                'additionalData' => 0,
                ];

        $payer = (object) [
                    'document' => $request->document,
                    'documentType' => documents::find($request->documentType)->cod,
                    'firstName' => $request->firstName,
                    'lastName' => $request->lastName,
                    'company' => 'Prueba PSE',
                    'emailAddress' => $request->emailAddress,
                    'address' => $request->address,
                    'city' => $request->city,
                    'province' => $request->province,
                    'country' => $request->country,
                    'phone' => $request->phone,
                    'mobile' => $request->phone
                    ];

        $transaction=$pseBase;

        $transaction->payer = $payer;
        $transaction->buyer = $payer;
        $transaction->shipping = $payer;

        $check = $mov->createTransaction($transaction);


        $mov = new placetopays();

        $mov->Guia = $date.$request->document;
        $mov->monto = $request->monto;
        $mov->description = $request->description;
        $mov->returnCode = (isset($check->returnCode) == true ? statuses::where('returnCode',$check->returnCode)->first()->id : '');
        $mov->trazabilityCode = (isset($check->trazabilityCode) == true ? $check->trazabilityCode : '');
        $mov->bankURL = (isset($check->bankURL) == true ? $check->bankURL : '');
        $mov->trazabilityCode = (isset($check->trazabilityCode) == true ? $check->trazabilityCode : '');
        $mov->transactionCycle = (isset($check->transactionCycle) == true ? $check->transactionCycle : '');
        $mov->transactionID = (isset($check->transactionID) == true ? $check->transactionID : '');
        $mov->sessionID = (isset($check->sessionID) == true ? $check->sessionID : '');
        $mov->bankCurrency = (isset($check->bankCurrency) == true ? $check->bankCurrency : '');
        $mov->bankFactor = (isset($check->bankFactor) == true ? $check->bankFactor : '');
        $mov->responseCode = (isset($check->responseCode) == true ? $check->responseCode : '');
        $mov->responseReasonCode = (isset($check->responseReasonCode) == true ? $check->responseReasonCode : '');
        $mov->responseReasonText = (isset($check->responseReasonText) == true ? $check->responseReasonText : '');

        $mov->save();


        return Redirect::to($mov->bankURL);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $mov = new SDKPSE($this->config());

        $dat = placetopays::where([['Guia',base64_decode($id)]])->first();

        if($dat == '')
        {
            flash('<i class="fa fa-warning"></i> No se han encontrado datos')->warning();
            return Redirect::route('listar');
        }

        $check = $mov->getTransactionInformation($dat->transactionID);

        $dat->reference = $check->reference;
        $dat->responseReasonText = $check->responseReasonText;
        $dat->save();

        return view('pagos.infoProceso',compact('check'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function listar()
    {
        $lis = placetopays::orderBy('created_at','desc')->paginate(5);

         if($lis[0] == null)
        {
            flash('<i class="fa fa-info"></i>&nbsp;&nbsp; No hay registros.')->info();

        }
        return view('pagos.historial',compact('lis'));
    }
}
