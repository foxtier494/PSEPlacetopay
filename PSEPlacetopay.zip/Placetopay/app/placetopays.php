<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class placetopays extends Model
{
    protected $table = 'placetopays';

    public function _returnCode()
    {
        return $this->belongsTo(statuses::class,'returnCode');
    }
}
