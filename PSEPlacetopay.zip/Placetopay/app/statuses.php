<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class statuses extends Model
{
    protected $table = 'statuses';

    public $timestamps = false;
}
