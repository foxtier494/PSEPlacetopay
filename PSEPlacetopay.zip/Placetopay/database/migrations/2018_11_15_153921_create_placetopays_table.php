<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlacetopaysTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('placetopays', function (Blueprint $table) {
            $table->increments('id');
            $table->string('Guia');
            $table->integer('transactionID');
            $table->string('sessionID',32);
            $table->string('trazabilityCode',40)->nullable();
            $table->integer('transactionCycle')->nullable();
            $table->string('bankCurrency',3)->nullable();
            $table->float('bankFactor', 8, 2)->nullable();
            $table->string('bankURL',255)->nullable();
            $table->integer('responseCode')->nullable();
            $table->string('responseReasonCode',3)->nullable();
            $table->string('responseReasonText',255)->nullable();


            $table->string('description')->nullable();
            $table->float('monto',12,2)->nullable();

            $table->bigInteger('reference')->nullable();

            $table->unsignedInteger('returnCode');
            $table->foreign('returnCode')->references('id')->on('statuses');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('placetopays');
    }
}
