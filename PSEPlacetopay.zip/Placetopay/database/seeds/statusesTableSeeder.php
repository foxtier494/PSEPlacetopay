<?php

use Faker\Generator;
use Styde\Seeder\Seeder;

class statusesTableSeeder extends Seeder
{
    protected $total = 1;

    public function getModel()
    {
        return new \App\statuses();
    }

    public function getDummyData(Generator $faker, array $custom = [])
    {
        return [
            //
        ];
    }

    public function create(array $customValues = array())
    {


        parent::create([
            'returnCode' => 'SUCCESS',
            'descripcion' => 'ÉXITO',
        ]);

        parent::create([
            'returnCode' => 'FAIL_INVALIDTRAZABILITYCODE',
            'descripcion' => 'CÓDIGO DE TRAZABILIDAD NO VÁLIDO',
        ]);

        parent::create([
            'returnCode' => 'FAIL_ACCESSDENIED',
            'descripcion' => 'ACCESO DENEGADO',
        ]);

        parent::create([
            'returnCode' => 'FAIL_INVALIDSTATE',
            'descripcion' => 'ESTADO INVÁLIDO',
        ]);

        parent::create([
            'returnCode' => 'FAIL_INVALIDBANKPROCESSINGDATE',
            'descripcion' => 'FECHA DE PROCESAMIENTO DEL BANCO NO VÁLIDO',
        ]);

        parent::create([
            'returnCode' => 'FAIL_INVALIDAUTHORIZEDAMOUNT',
            'descripcion' => 'CANTIDAD AUTORIZADA NO VÁLIDA',
        ]);

        parent::create([
            'returnCode' => 'FAIL_INCONSISTENTDATA',
            'descripcion' => 'DATOS INCONSISTENTES',
        ]);

        parent::create([
            'returnCode' => 'FAIL_TIMEOUT',
            'descripcion' => 'SE ACABÓ EL TIEMPO',
        ]);

        parent::create([
            'returnCode' => 'FAIL_INVALIDVATVALUE',
            'descripcion' => 'VALOR NO VÁLIDO',
        ]);

        parent::create([
            'returnCode' => 'FAIL_INVALIDTICKETID',
            'descripcion' => 'TICKETID INVALIDO',
        ]);

        parent::create([
            'returnCode' => 'FAIL_INVALIDSOLICITEDATE',
            'descripcion' => 'FECHA SOLICITA NO VÁLIDA',
        ]);

        parent::create([
            'returnCode' => 'FAIL_INVALIDAUTHORIZATIONID',
            'descripcion' => 'ID DE AUTORIZACIÓN NO VÁLIDA',
        ]);

        parent::create([
            'returnCode' => 'FAIL_TRANSACTIONNOTALLOWED',
            'descripcion' => 'TRANSACCIÓN NO PERMITIDA',
        ]);

        parent::create([
            'returnCode' => 'FAIL_ERRORINCREDITS',
            'descripcion' => 'ERRORES DE INCREDITOS',
        ]);

        parent::create([
            'returnCode' => 'FAIL_EXCEEDEDLIMIT',
            'descripcion' => 'LÍMITE EXCEDIDO',
        ]);

    }
}
