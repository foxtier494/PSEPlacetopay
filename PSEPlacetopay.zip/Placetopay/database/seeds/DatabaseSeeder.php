<?php

use Styde\Seeder\BaseSeeder;

class DatabaseSeeder extends BaseSeeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    protected $truncate = array(
        //'Truncate Tablas de DB MYSQL',
        'placetopays',
        'statuses',
    );

    protected $seeders = array(
        //'Seeders User',
        'statuses',
        'documents',


    );
}
