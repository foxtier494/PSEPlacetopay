<?php

use Faker\Generator;
use Styde\Seeder\Seeder;

class documentsTableSeeder extends Seeder
{
    protected $total = 1;

    public function getModel()
    {
        return new \App\documents();
    }

    public function getDummyData(Generator $faker, array $custom = [])
    {
        return [
            //
        ];
    }

    public function create(array $customValues = array())
    {

        parent::create([
            'cod' => 'CC',
            'descripcion' => 'Cédula de ciudanía colombiana',
        ]);


        parent::create([
            'cod' => 'CE',
            'descripcion' => 'Cédula de extranjería',
        ]);


        parent::create([
            'cod' => 'TI',
            'descripcion' => 'Tarjeta de identidad',
        ]);


        parent::create([
            'cod' => 'PPN',
            'descripcion' => 'Pasaporte',
        ]);


        parent::create([
            'cod' => 'NIT',
            'descripcion' => 'Número de identificación tributaria',
        ]);


        parent::create([
            'cod' => 'SSN',
            'descripcion' => 'Social Security Number',
        ]);

    }
}
