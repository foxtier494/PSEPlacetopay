<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','indexController@index')->name('index');
Route::get('/create','indexController@create')->name('create');
Route::post('/','indexController@store')->name('store');
Route::get('/historial/','indexController@listar')->name('listar');
Route::get('/{id}','indexController@show')->name('show');





