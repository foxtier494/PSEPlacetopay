<!DOCTYPE HTML>
<html>
<head>
    <!-- SwetAlert -->
    <script src="{{ asset('sweetalert/sweetalert2.min.js')  }}"></script>
    <!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
    <script src="{{ asset('sweetalert/core.js') }}"></script>
    <link rel="stylesheet" href="{{ asset('sweetalert/sweetalert2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/font-awesome.css') }}">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="{{ asset('bootstrap/bootstrap.min.css') }}">

    <link rel="stylesheet" href="{{ asset('fonts/font-awesome.css') }}">


    <title>Login</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" type="text/css" href="{{ asset('/css/app.css') }}">
</head>
<body>

@include('layout.menu')

<div style="width:55%; margin:0 auto;">
    @include('flash::message')
</div>

<!-- Main -->
<div id="app" >
    @yield('content')
</div>

<!-- Scripts -->
<script>
    window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?>
</script>
<script src="{{ asset('jquery.min.js') }}"></script>
<script src="{{ asset('bootstrap/bootstrap.min.js') }}"></script>
<script src="{{ asset('js/app.js') }}"></script>

<script>
    $('#flash-overlay-modal').modal();
</script>
</body>
</html>