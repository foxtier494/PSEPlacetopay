@extends('layout.disenioBase')
@section('content')

    <table class="table" style="margin: 0 auto; width: 70%; margin-top: 5%;">
        <tr>
            <td style="text-align: center;" colspan="3">
                <h3 style="margin-bottom: 5%;"><i class="fa fa-gears"></i> Flujo para pruebas PSE</h3>
            </td>
        </tr>

        <tr style="text-align: center;">
            <td style="border-right: solid 1px black;">
                <a href="{{ route('create') }}">
                    <button class="btn btn-primary"> <i class="fa fa-credit-card"></i> Realizar proceso de pago</button>
                </a>
            </td>

            <td>
                <a href="{{ route('listar') }}">
                    <button class="btn btn-info"> <i class="fa fa-list"></i> Listar historial de pagos</button>
                </a>
            </td>
        </tr>

    </table>

@endsection