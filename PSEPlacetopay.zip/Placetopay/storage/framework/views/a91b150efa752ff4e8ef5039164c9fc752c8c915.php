<?php $__env->startSection('content'); ?>

    <table class="table" style="margin: 0 auto; width: 70%; margin-top: 5%;">
        <tr>
            <td style="text-align: center;">
                <h3 style="margin-bottom: 5%;"><i class="fa fa-credit-card"></i> Flujo para pruebas PSE</h3>
            </td>
        </tr>

        <tr>
            <td>
                <label>Indique tipo de cuenta con la cual realizára el proceso.</label>
                <select name="" id="" class="form-control">
                    <option>-Selecionar-</option>
                </select>
            </td>
        </tr>

        <tr>
            <td>
                <label>Selecione de la lista la entidad financiera con la que desea realizar el pago.</label>
                <select name="" id="" class="form-control">
                    <option>-Selecionar Banco-</option>
                </select>
            </td>
        </tr>

        <tr>
            <td style="text-align: center;">
                <br>
                <button class="btn btn-primary" style="width: 35%;"><i class="fa fa-arrow-right"></i> Continuar</button>
            </td>
        </tr>

    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.disenioBase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>