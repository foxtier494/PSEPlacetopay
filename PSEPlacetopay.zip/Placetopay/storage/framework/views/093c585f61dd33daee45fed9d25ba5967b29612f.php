<!DOCTYPE HTML>
<html>
<head>
    <!-- SwetAlert -->
    <script src="<?php echo e(asset('sweetalert/sweetalert2.min.js')); ?>"></script>
    <!-- Include a polyfill for ES6 Promises (optional) for IE11 and Android browser -->
    <script src="<?php echo e(asset('sweetalert/core.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('sweetalert/sweetalert2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.css')); ?>">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('fonts/font-awesome.css')); ?>">


    <title>Login</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/app.css')); ?>">
</head>
<body>

<?php echo $__env->make('layout.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div style="width:55%; margin:0 auto;">
    <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<!-- Main -->
<div id="app" >
    <?php echo $__env->yieldContent('content'); ?>
</div>

<!-- Scripts -->
<script>
    window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?>
</script>
<script src="<?php echo e(asset('jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>

<script>
    $('#flash-overlay-modal').modal();
</script>
</body>
</html>