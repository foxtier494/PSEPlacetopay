<?php $__env->startSection('content'); ?>

    <?php echo Form::open(['url' => route('store'), 'method' => 'POST']); ?>

    <table class="table" style="margin: 0 auto; width: 70%; margin-top: 5%;">
        <tr>
            <td style="text-align: center;" colspan="2">
                <h3 style="margin-bottom: 5%;"><i class="fa fa-credit-card"></i> Simulación de pago PSE</h3>
            </td>
        </tr>

        <tr>
            <td >
                <label>Selecione tipo documento</label>
                <select name="documentType" id="" class="form-control" required>
                    <option value="">-Selecione tipo de documento-</option>
                    <?php $__currentLoopData = $listDocumentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listDocumento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($listDocumento->id); ?>" <?php echo e($listDocumento->id == 1 ? 'selected' : ''); ?>><?php echo e($listDocumento->descripcion); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
            <td>
                <label>N° Documento</label>
                <input type="text" name="document" value="20121827" class="form-control" required>
            </td>
        </tr>

        <tr>
            <td style="width: 50%;">
                <label>Indique tipo de cuenta.</label>
                <select name="bankInterface" id="" class="form-control" required>
                    <option value="">-Selecionar-</option>
                    <option value="0" selected>Persona</option>
                    <option value="1">Empresa</option>
                </select>
            </td>
            <td>
                <label>Selecione de la lista la entidad financiera.</label>
                <select name="bankCode" id="" class="form-control" required>
                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bank->bankCode); ?>" <?php echo e($bank->bankCode == 1022 ? 'selected' : ''); ?>><?php echo e($bank->bankName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
        </tr>


        <tr>
            <td>
                <label>Nombre</label>
                <input type="text" name="firstName" value="PRUEBAS" class="form-control" required>
            </td>
            <td>
                <label>Apellido</label>
                <input type="text" name="lastName" value="PSE" class="form-control" required>
            </td>
        </tr>
        <input type="hidden" name="country" value="CO" class="form-control">
        <input type="hidden" name="province" value="Antioquia" class="form-control">
        <input type="hidden" name="city" value="Medellín" class="form-control">

        <tr>
            <td>
                <label>Número de celular</label>
                <input type="text" name="phone" value="4020000001" class="form-control" required>
            </td>
            <td>
                <label>Descipción del producto</label>
                <input type="text" name="description" value="Pago pruebas <?php echo e(date('h:m:s')); ?>" class="form-control" required>
            </td>
        </tr>

        <tr>
            <td>
                <label>Correo</label>
                <input type="email" name="emailAddress" value="theshark3232@gmail.com" class="form-control" required>
            </td>
            <td>
                <label>Dirección de residencia u oficina</label>
                <input type="text" name="address" value="San Lorenzo" class="form-control" required>
            </td>
        </tr>

        <tr>
            <td colspan="2">
                <label>Monto a Pagar</label>
                <input type="text" readonly value="100000" name="monto" class="form-control">
            </td>
        </tr>


        <tr>
            <td style="text-align: center;" colspan="2">
                <br>
                <button class="btn btn-primary" style="width: 35%;"><i class="fa fa-arrow-right"></i> Continuar</button>
            </td>
        </tr>

    </table>
    <?php echo @Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.disenioBase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>