<?php $__env->startSection('content'); ?>

   <table class="table" style="margin: 0 auto; width: 70%; margin-top: 5%;">
        <tr>
            <td style="text-align: center;" colspan="2">
                <h3 style="margin-bottom: 5%;"><i class="fa fa-eye"></i> Estatus de Operación</h3>
            </td>
        </tr>


       <tr>
           <td ><b>Transacción ID</b>: <?php echo e($check->transactionID); ?></td>
           <td style="text-align: right;"><b>Referencia</b>: <?php echo e($check->reference); ?></td>
       </tr>

       <tr>
           <td colspan="2"><b>El estado de la Operacion es</b>: <?php echo e(\App\statuses::where('returnCode',$check->returnCode)->first()->descripcion); ?> <?php echo e($check->responseReasonText); ?></td>
       </tr>


       <tr>
           <td colspan="2" style="text-align: center; padding-top: 5%;"><a href="<?php echo e(route('index')); ?>" ><button style="width: 35%;" class="btn btn-warning"> <i class="fa fa-home"></i> Ir al inicio</button></a></td>
       </tr>



    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.disenioBase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>