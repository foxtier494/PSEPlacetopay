<?php $__env->startSection('content'); ?>

    <table class="table" style="margin: 0 auto; width: 70%; margin-top: 5%;">
        <tr>
            <td style="text-align: center;" colspan="4">
                <h3 style="margin-bottom: 5%;"><i class="fa fa-eye"></i> Historail de Operaciones</h3>
            </td>
        </tr>

        <tr>
            <th>Transacción ID</th>
            <th>Referencia</th>
            <th style="text-align: right;">Monto</th>
            <th style="text-align: right;">Fecha de Transaccion</th>
        </tr>

        <?php $__currentLoopData = $lis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $li): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td title="<?php echo e($li->description); ?>"><?php echo e($li->transactionID); ?></td>
            <td><a href="<?php echo e(route('show',base64_encode($li->Guia))); ?>"><?php echo e($li->reference); ?></a></td>
            <td style="text-align: right;"><?php echo e(number_format($li->monto, 2)); ?></td>
            <td style="text-align: right;"><?php echo e(date_format($li->created_at,"d/m/Y h:i:s")); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td colspan="4" style="text-align: center;">
                <?php echo $lis->render(); ?>

            </td>
        </tr>


    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.disenioBase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>